export enum KeyCodes { // for now keys are a bit redundant but i know it will be useful in future
    Control = "Control",
    Escape = "Escape",
}