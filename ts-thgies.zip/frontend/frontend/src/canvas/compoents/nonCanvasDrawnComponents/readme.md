
// these are components that inside the canvas but are not drawn by the canvas but instead are html elements interacting with the canvas