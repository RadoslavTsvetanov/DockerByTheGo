class Scale{
    private value: number;
    constructor() {
        this.value = 1
    }
}